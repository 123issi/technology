'use client';

import Link from 'next/link';
import { useState } from 'react';

interface CourseDetailProps {
  courseId: string;
}

export default function CourseDetail({ courseId }: CourseDetailProps) {
  const [activeTab, setActiveTab] = useState('overview');

  const courses = {
    '1': {
      title: 'Software Development',
      duration: '12 months',
      level: 'Beginner to Advanced',
      certType: 'Industry Certificate',
      description: 'Comprehensive training in modern programming languages including Python, Java, and JavaScript. Learn software architecture, database design, and agile development methodologies.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20software%20development%20workspace%20with%20multiple%20monitors%20showing%20code%2C%20programming%20languages%20logos%2C%20clean%20office%20environment%20with%20natural%20lighting%2C%20professional%20tech%20setup&width=800&height=400&seq=software-dev&orientation=landscape',
      modules: [
        { name: 'Programming Fundamentals', duration: '2 months', topics: ['Variables & Data Types', 'Control Structures', 'Functions', 'Object-Oriented Programming'] },
        { name: 'Web Development', duration: '3 months', topics: ['HTML/CSS', 'JavaScript', 'React Framework', 'Node.js Backend'] },
        { name: 'Database Design', duration: '2 months', topics: ['SQL Basics', 'Database Modeling', 'MongoDB', 'Data Security'] },
        { name: 'Software Engineering', duration: '3 months', topics: ['Version Control (Git)', 'Testing', 'Deployment', 'Agile Methodology'] },
        { name: 'Capstone Project', duration: '2 months', topics: ['Full-stack Application', 'Team Collaboration', 'Presentation Skills', 'Portfolio Development'] }
      ],
      prerequisites: 'Basic computer skills and eagerness to learn',
      careers: ['Software Developer', 'Web Developer', 'Full-stack Developer', 'Frontend Developer', 'Backend Developer'],
      salary: '$45,000 - $120,000 annually'
    },
    '2': {
      title: 'Cybersecurity',
      duration: '8 months',
      level: 'Intermediate',
      certType: 'CompTIA Security+',
      description: 'Master cybersecurity fundamentals, threat analysis, network security, and incident response. Prepare for industry-standard security roles.',
      image: 'https://readdy.ai/api/search-image?query=Cybersecurity%20operations%20center%20with%20security%20analysts%20monitoring%20network%20threats%2C%20multiple%20screens%20showing%20security%20dashboards%2C%20professional%20blue%20lighting%2C%20modern%20tech%20environment&width=800&height=400&seq=cybersecurity&orientation=landscape',
      modules: [
        { name: 'Security Fundamentals', duration: '2 months', topics: ['CIA Triad', 'Risk Management', 'Compliance', 'Security Policies'] },
        { name: 'Network Security', duration: '2 months', topics: ['Firewalls', 'VPNs', 'Intrusion Detection', 'Network Protocols'] },
        { name: 'Threat Analysis', duration: '2 months', topics: ['Malware Analysis', 'Vulnerability Assessment', 'Penetration Testing', 'Incident Response'] },
        { name: 'Security Tools', duration: '2 months', topics: ['SIEM Solutions', 'Security Scanning', 'Forensics Tools', 'Monitoring Systems'] }
      ],
      prerequisites: 'Basic networking knowledge recommended',
      careers: ['Security Analyst', 'Cybersecurity Specialist', 'Information Security Officer', 'Security Consultant'],
      salary: '$55,000 - $140,000 annually'
    },
    '3': {
      title: 'Web Application Development',
      duration: '10 months',
      level: 'Beginner to Advanced',
      certType: 'Industry Certificate',
      description: 'Build modern web applications using HTML, CSS, JavaScript, React, and Node.js. Learn responsive design and full-stack development.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20web%20development%20studio%20with%20developers%20working%20on%20responsive%20websites%2C%20multiple%20devices%20showing%20web%20applications%2C%20clean%20workspace%20with%20natural%20lighting&width=800&height=400&seq=web-dev&orientation=landscape',
      modules: [
        { name: 'Frontend Fundamentals', duration: '3 months', topics: ['HTML5', 'CSS3', 'JavaScript ES6+', 'Responsive Design'] },
        { name: 'Modern Frontend', duration: '3 months', topics: ['React.js', 'State Management', 'Component Libraries', 'Testing'] },
        { name: 'Backend Development', duration: '2 months', topics: ['Node.js', 'Express.js', 'APIs', 'Authentication'] },
        { name: 'Full-stack Integration', duration: '2 months', topics: ['Database Integration', 'Deployment', 'Performance Optimization', 'Security'] }
      ],
      prerequisites: 'Basic computer skills',
      careers: ['Frontend Developer', 'Full-stack Developer', 'Web Developer', 'UI/UX Developer'],
      salary: '$50,000 - $115,000 annually'
    },
    '4': {
      title: 'Ethical Hacking',
      duration: '6 months',
      level: 'Advanced',
      certType: 'CEH, eJPT',
      description: 'Learn penetration testing, vulnerability assessment, and ethical hacking techniques. Hands-on training with real-world scenarios.',
      image: 'https://readdy.ai/api/search-image?query=Ethical%20hacking%20laboratory%20with%20penetration%20testing%20tools%2C%20security%20testing%20environment%2C%20multiple%20terminals%20showing%20hacking%20simulations%2C%20professional%20cybersecurity%20setup&width=800&height=400&seq=ethical-hack&orientation=landscape',
      modules: [
        { name: 'Reconnaissance', duration: '1 month', topics: ['Information Gathering', 'Footprinting', 'Scanning', 'Enumeration'] },
        { name: 'Vulnerability Assessment', duration: '2 months', topics: ['Web App Testing', 'Network Vulnerabilities', 'System Weaknesses', 'Report Writing'] },
        { name: 'Exploitation Techniques', duration: '2 months', topics: ['Buffer Overflows', 'SQL Injection', 'XSS Attacks', 'Privilege Escalation'] },
        { name: 'Post-Exploitation', duration: '1 month', topics: ['Maintaining Access', 'Covering Tracks', 'Documentation', 'Remediation'] }
      ],
      prerequisites: 'Strong networking and security fundamentals',
      careers: ['Penetration Tester', 'Security Consultant', 'Ethical Hacker', 'Security Researcher'],
      salary: '$70,000 - $160,000 annually'
    },
    '5': {
      title: 'Cloud Computing (Azure)',
      duration: '9 months',
      level: 'Intermediate',
      certType: 'Microsoft Azure Certificates',
      description: 'Master Microsoft Azure cloud services, deployment, and management. Free exam vouchers included for girls.',
      image: 'https://readdy.ai/api/search-image?query=Modern%20cloud%20computing%20center%20with%20Azure%20services%20dashboard%2C%20server%20infrastructure%2C%20cloud%20technology%20visualization%2C%20professional%20blue%20and%20white%20environment&width=800&height=400&seq=azure-cloud&orientation=landscape',
      modules: [
        { name: 'Azure Fundamentals', duration: '2 months', topics: ['Cloud Concepts', 'Azure Services', 'Pricing', 'Support'] },
        { name: 'Azure Administration', duration: '3 months', topics: ['Virtual Machines', 'Storage', 'Networking', 'Identity Management'] },
        { name: 'Azure Development', duration: '2 months', topics: ['App Services', 'Functions', 'Containers', 'DevOps'] },
        { name: 'Azure Security & Monitoring', duration: '2 months', topics: ['Security Center', 'Key Vault', 'Monitor', 'Backup'] }
      ],
      prerequisites: 'Basic IT knowledge',
      careers: ['Cloud Administrator', 'Azure Developer', 'Cloud Architect', 'DevOps Engineer'],
      salary: '$60,000 - $150,000 annually'
    },
    '6': {
      title: 'CompTIA A+',
      duration: '4 months',
      level: 'Beginner',
      certType: 'CompTIA A+',
      description: 'Foundation course for IT support and hardware troubleshooting. Perfect entry point into technology careers.',
      image: 'https://readdy.ai/api/search-image?query=IT%20support%20technician%20working%20with%20computer%20hardware%2C%20troubleshooting%20equipment%2C%20organized%20tech%20repair%20workspace%2C%20professional%20learning%20environment&width=800&height=400&seq=comptia-a&orientation=landscape',
      modules: [
        { name: 'Hardware', duration: '2 months', topics: ['Computer Components', 'Mobile Devices', 'Hardware Troubleshooting', 'Printers'] },
        { name: 'Operating Systems', duration: '1 month', topics: ['Windows', 'macOS', 'Linux', 'Mobile OS'] },
        { name: 'Software & Security', duration: '1 month', topics: ['Software Installation', 'Malware Removal', 'Security Best Practices', 'Operational Procedures'] }
      ],
      prerequisites: 'None - perfect for beginners',
      careers: ['IT Support Specialist', 'Help Desk Technician', 'Desktop Support', 'Field Service Technician'],
      salary: '$35,000 - $55,000 annually'
    },
    '7': {
      title: 'CompTIA Security+',
      duration: '5 months',
      level: 'Intermediate',
      certType: 'CompTIA Security+',
      description: 'Essential cybersecurity skills and knowledge. Industry-recognized certification for security professionals.',
      image: 'https://readdy.ai/api/search-image?query=Cybersecurity%20training%20environment%20with%20security%20concepts%20visualization%2C%20network%20security%20diagrams%2C%20professional%20learning%20setup%20with%20security%20tools&width=800&height=400&seq=security-plus&orientation=landscape',
      modules: [
        { name: 'Security Concepts', duration: '1 month', topics: ['CIA Triad', 'Risk Management', 'Threat Landscape', 'Security Controls'] },
        { name: 'Technologies & Tools', duration: '2 months', topics: ['Firewalls', 'VPNs', 'Wireless Security', 'Mobile Security'] },
        { name: 'Architecture & Design', duration: '1 month', topics: ['Secure Network Design', 'Cloud Security', 'Application Security', 'Physical Security'] },
        { name: 'Identity & Risk Management', duration: '1 month', topics: ['Authentication', 'Authorization', 'Risk Assessment', 'Incident Response'] }
      ],
      prerequisites: 'CompTIA A+ or equivalent experience recommended',
      careers: ['Security Specialist', 'Security Administrator', 'Systems Administrator', 'Network Administrator'],
      salary: '$50,000 - $85,000 annually'
    },
    '8': {
      title: 'CompTIA Network+',
      duration: '6 months',
      level: 'Intermediate',
      certType: 'CompTIA Network+',
      description: 'Comprehensive networking fundamentals, protocols, and infrastructure management. Build strong networking foundation.',
      image: 'https://readdy.ai/api/search-image?query=Network%20operations%20center%20with%20network%20topology%20diagrams%2C%20routing%20equipment%2C%20cable%20management%2C%20professional%20networking%20environment&width=800&height=400&seq=network-plus&orientation=landscape',
      modules: [
        { name: 'Networking Concepts', duration: '2 months', topics: ['OSI Model', 'TCP/IP', 'Subnetting', 'VLANs'] },
        { name: 'Infrastructure', duration: '2 months', topics: ['Routing', 'Switching', 'Wireless', 'WAN Technologies'] },
        { name: 'Network Operations', duration: '1 month', topics: ['Monitoring', 'Optimization', 'Disaster Recovery', 'Policies'] },
        { name: 'Network Security', duration: '1 month', topics: ['Access Control', 'Firewalls', 'VPN', 'Wireless Security'] }
      ],
      prerequisites: 'CompTIA A+ recommended',
      careers: ['Network Administrator', 'Network Technician', 'Network Support Specialist', 'Junior Network Engineer'],
      salary: '$45,000 - $75,000 annually'
    },
    '9': {
      title: 'OSCP Preparation',
      duration: '12 months',
      level: 'Advanced',
      certType: 'OSCP',
      description: 'Intensive penetration testing training preparing for the prestigious OSCP certification. Hands-on lab experience included.',
      image: 'https://readdy.ai/api/search-image?query=Advanced%20penetration%20testing%20laboratory%20with%20multiple%20virtual%20machines%2C%20security%20testing%20tools%2C%20command%20line%20interfaces%2C%20professional%20ethical%20hacking%20environment&width=800&height=400&seq=oscp-prep&orientation=landscape',
      modules: [
        { name: 'Linux Administration', duration: '2 months', topics: ['Command Line', 'System Administration', 'Shell Scripting', 'Services'] },
        { name: 'Web Application Testing', duration: '3 months', topics: ['OWASP Top 10', 'Manual Testing', 'Automated Tools', 'Code Review'] },
        { name: 'Network Penetration', duration: '3 months', topics: ['Service Enumeration', 'Exploitation', 'Post-Exploitation', 'Privilege Escalation'] },
        { name: 'Buffer Overflows', duration: '2 months', topics: ['Stack Overflows', 'Shellcoding', 'ASLR/DEP Bypass', 'Exploit Development'] },
        { name: 'Exam Preparation', duration: '2 months', topics: ['Lab Practice', 'Report Writing', 'Time Management', 'Methodology'] }
      ],
      prerequisites: 'Strong Linux/Windows knowledge, networking, and scripting',
      careers: ['Senior Penetration Tester', 'Security Consultant', 'Red Team Specialist', 'Security Researcher'],
      salary: '$90,000 - $180,000 annually'
    },
    '10': {
      title: 'CCNA Cisco Networking',
      duration: '8 months',
      level: 'Intermediate',
      certType: 'CCNA',
      description: 'Cisco networking fundamentals, routing, switching, and network troubleshooting. Industry-standard networking certification.',
      image: 'https://readdy.ai/api/search-image?query=Cisco%20networking%20laboratory%20with%20routers%20and%20switches%2C%20network%20equipment%20rack%2C%20professional%20networking%20training%20environment%20with%20Cisco%20devices&width=800&height=400&seq=ccna&orientation=landscape',
      modules: [
        { name: 'Network Fundamentals', duration: '2 months', topics: ['OSI & TCP Models', 'Ethernet', 'IPv4/IPv6', 'Wireless Fundamentals'] },
        { name: 'Switching Technologies', duration: '2 months', topics: ['VLANs', 'Trunking', 'STP', 'EtherChannel'] },
        { name: 'Routing Technologies', duration: '2 months', topics: ['Static Routing', 'OSPF', 'EIGRP', 'BGP Basics'] },
        { name: 'WAN & Security', duration: '2 months', topics: ['WAN Technologies', 'VPN', 'ACLs', 'Device Security'] }
      ],
      prerequisites: 'Basic networking knowledge',
      careers: ['Network Engineer', 'Network Administrator', 'Systems Engineer', 'Network Support Engineer'],
      salary: '$55,000 - $95,000 annually'
    },
    '11': {
      title: 'CCNP Advanced Networking',
      duration: '14 months',
      level: 'Advanced',
      certType: 'CCNP',
      description: 'Advanced Cisco networking technologies, enterprise networking solutions, and complex network implementations.',
      image: 'https://readdy.ai/api/search-image?query=Advanced%20enterprise%20network%20operations%20center%20with%20complex%20routing%20equipment%2C%20multiple%20monitoring%20screens%2C%20professional%20network%20engineering%20environment&width=800&height=400&seq=ccnp&orientation=landscape',
      modules: [
        { name: 'Enterprise Core', duration: '4 months', topics: ['Advanced Routing', 'Switching', 'Wireless', 'Network Assurance'] },
        { name: 'Enterprise Advanced Routing', duration: '3 months', topics: ['OSPF', 'EIGRP', 'BGP', 'Route Redistribution'] },
        { name: 'Enterprise Advanced Switching', duration: '3 months', topics: ['Advanced STP', 'VTP', 'Advanced VLANs', 'Troubleshooting'] },
        { name: 'Automation & Programmability', duration: '2 months', topics: ['Python', 'APIs', 'Configuration Management', 'Network Automation'] },
        { name: 'Advanced Troubleshooting', duration: '2 months', topics: ['Methodology', 'Tools', 'Performance Optimization', 'Case Studies'] }
      ],
      prerequisites: 'CCNA certification or equivalent experience',
      careers: ['Senior Network Engineer', 'Network Architect', 'Network Consultant', 'Infrastructure Specialist'],
      salary: '$75,000 - $130,000 annually'
    }
  };

  const course = courses[courseId as keyof typeof courses];

  if (!course) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Course Not Found</h1>
          <Link href="/">
            <button className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer">
              Back to Home
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-blue-700 to-red-600 text-white shadow-lg">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <div className="flex items-center space-x-4 cursor-pointer">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-xl">EAGT</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold font-pacifico">East African Girls in Tech</h1>
                  <p className="text-blue-100 text-sm">Empowering East African Girls in Technology</p>
                </div>
              </div>
            </Link>
            <Link href="/apply">
              <button className="bg-white text-blue-600 px-6 py-2 rounded-full font-semibold hover:bg-blue-50 transition-colors whitespace-nowrap cursor-pointer">
                Apply Now
              </button>
            </Link>
          </div>
        </div>
      </header>

      {/* Course Hero */}
      <section className="relative py-16 bg-gradient-to-r from-blue-600 to-red-600 text-white">
        <div className="absolute inset-0 bg-black/30"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{backgroundImage: `url(${course.image})`}}
        ></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <div className="flex items-center space-x-4 mb-4">
              <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm font-medium">
                {course.duration}
              </span>
              <span className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                FREE
              </span>
              <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm font-medium">
                {course.level}
              </span>
            </div>
            <h2 className="text-5xl font-bold mb-4">{course.title}</h2>
            <p className="text-xl mb-6 text-blue-100">{course.description}</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/apply">
                <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors whitespace-nowrap cursor-pointer">
                  Enroll Now - Free
                </button>
              </Link>
              <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white/10 transition-colors whitespace-nowrap cursor-pointer">
                Download Syllabus
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Course Details */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            {/* Tab Navigation */}
            <div className="flex flex-wrap gap-2 mb-8 border-b border-gray-200">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'curriculum', label: 'Curriculum' },
                { id: 'career', label: 'Career Paths' },
                { id: 'requirements', label: 'Requirements' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-6 py-3 rounded-t-lg font-medium transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              {activeTab === 'overview' && (
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-4">Course Overview</h3>
                    <p className="text-gray-600 mb-6">{course.description}</p>
                    
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <i className="ri-time-line w-5 h-5 flex items-center justify-center text-blue-600 mr-3"></i>
                        <span><strong>Duration:</strong> {course.duration}</span>
                      </div>
                      <div className="flex items-center">
                        <i className="ri-user-line w-5 h-5 flex items-center justify-center text-blue-600 mr-3"></i>
                        <span><strong>Level:</strong> {course.level}</span>
                      </div>
                      <div className="flex items-center">
                        <i className="ri-award-line w-5 h-5 flex items-center justify-center text-blue-600 mr-3"></i>
                        <span><strong>Certification:</strong> {course.certType}</span>
                      </div>
                      <div className="flex items-center">
                        <i className="ri-money-dollar-circle-line w-5 h-5 flex items-center justify-center text-green-600 mr-3"></i>
                        <span><strong>Cost:</strong> Free for eligible applicants</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-4">What You'll Learn</h3>
                    <ul className="space-y-3">
                      {course.modules.slice(0, 6).map((module, index) => (
                        <li key={index} className="flex items-start">
                          <i className="ri-check-line w-5 h-5 flex items-center justify-center text-green-600 mr-3 mt-0.5"></i>
                          <span>{module.topics[0]} and more in {module.name}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {activeTab === 'curriculum' && (
                <div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-6">Course Curriculum</h3>
                  <div className="space-y-6">
                    {course.modules.map((module, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="text-xl font-semibold text-gray-800">{module.name}</h4>
                          <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium">
                            {module.duration}
                          </span>
                        </div>
                        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3">
                          {module.topics.map((topic, topicIndex) => (
                            <div key={topicIndex} className="flex items-center">
                              <i className="ri-play-circle-line w-4 h-4 flex items-center justify-center text-gray-400 mr-2"></i>
                              <span className="text-sm text-gray-600">{topic}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'career' && (
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-6">Career Opportunities</h3>
                    <div className="space-y-4">
                      {course.careers.map((career, index) => (
                        <div key={index} className="flex items-center p-4 bg-blue-50 rounded-lg">
                          <i className="ri-briefcase-line w-6 h-6 flex items-center justify-center text-blue-600 mr-4"></i>
                          <span className="font-medium text-gray-800">{career}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-6">Salary Expectations</h3>
                    <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg">
                      <div className="text-center">
                        <i className="ri-money-dollar-circle-line w-12 h-12 flex items-center justify-center text-green-600 mx-auto mb-4"></i>
                        <p className="text-2xl font-bold text-gray-800 mb-2">{course.salary}</p>
                        <p className="text-gray-600">Average salary range for graduates</p>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <h4 className="text-lg font-semibold mb-4">Career Support</h4>
                      <ul className="space-y-2">
                        <li className="flex items-center">
                          <i className="ri-check-line w-4 h-4 flex items-center justify-center text-green-600 mr-2"></i>
                          <span className="text-sm">Resume and LinkedIn optimization</span>
                        </li>
                        <li className="flex items-center">
                          <i className="ri-check-line w-4 h-4 flex items-center justify-center text-green-600 mr-2"></i>
                          <span className="text-sm">Interview preparation</span>
                        </li>
                        <li className="flex items-center">
                          <i className="ri-check-line w-4 h-4 flex items-center justify-center text-green-600 mr-2"></i>
                          <span className="text-sm">Job placement assistance</span>
                        </li>
                        <li className="flex items-center">
                          <i className="ri-check-line w-4 h-4 flex items-center justify-center text-green-600 mr-2"></i>
                          <span className="text-sm">Networking opportunities</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'requirements' && (
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-6">Prerequisites</h3>
                    <div className="bg-blue-50 p-6 rounded-lg">
                      <p className="text-gray-700">{course.prerequisites}</p>
                    </div>
                    
                    <h4 className="text-lg font-semibold mt-6 mb-4">Technical Requirements</h4>
                    <ul className="space-y-3">
                      <li className="flex items-center">
                        <i className="ri-computer-line w-5 h-5 flex items-center justify-center text-blue-600 mr-3"></i>
                        <span>Computer with reliable internet connection</span>
                      </li>
                      <li className="flex items-center">
                        <i className="ri-time-line w-5 h-5 flex items-center justify-center text-blue-600 mr-3"></i>
                        <span>10-15 hours per week study time</span>
                      </li>
                      <li className="flex items-center">
                        <i className="ri-english-input w-5 h-5 flex items-center justify-center text-blue-600 mr-3"></i>
                        <span>Basic English proficiency</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800 mb-6">Application Process</h3>
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold mr-4 mt-1">1</div>
                        <div>
                          <h5 className="font-semibold">Submit Application</h5>
                          <p className="text-gray-600 text-sm">Complete the online application form</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold mr-4 mt-1">2</div>
                        <div>
                          <h5 className="font-semibold">Assessment</h5>
                          <p className="text-gray-600 text-sm">Basic skills assessment and interview</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold mr-4 mt-1">3</div>
                        <div>
                          <h5 className="font-semibold">Acceptance</h5>
                          <p className="text-gray-600 text-sm">Receive acceptance notification via email</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <div className="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center font-bold mr-4 mt-1">4</div>
                        <div>
                          <h5 className="font-semibold">Start Learning</h5>
                          <p className="text-gray-600 text-sm">Begin your tech journey!</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-red-600 text-white">
        <div className="container mx-auto px-6 text-center">
          <h3 className="text-3xl font-bold mb-4">Ready to Start Your {course.title} Journey?</h3>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of East African women building successful tech careers. Apply today and transform your future.
          </p>
          <Link href="/apply">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-50 transition-colors whitespace-nowrap cursor-pointer">
              Apply Now - It's Free!
            </button>
          </Link>
        </div>
      </section>
    </div>
  );
}