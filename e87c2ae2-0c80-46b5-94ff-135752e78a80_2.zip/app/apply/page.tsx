'use client';

import { useState } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, collection, addDoc } from 'firebase/firestore';
import Link from 'next/link';

const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "your-app-id"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export default function ApplyPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    country: '',
    city: '',
    dateOfBirth: '',
    education: '',
    course: '',
    experience: '',
    motivation: '',
    goals: '',
    availability: '',
    computer: '',
    internet: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');
  const [showLogin, setShowLogin] = useState(false);
  const [loginData, setLoginData] = useState({ email: '', password: '' });

  const countries = [
    'South Africa', 'DR Congo', 'Tanzania', 'Rwanda', 'Burundi',
    'Kenya', 'Uganda', 'South Sudan', 'Somalia'
  ];

  const courses = [
    'Software Development',
    'Cybersecurity',
    'Web Application Development',
    'Ethical Hacking',
    'Cloud Computing (Azure)',
    'CompTIA A+',
    'CompTIA Security+',
    'CompTIA Network+',
    'OSCP Preparation',
    'CCNA Cisco Networking',
    'CCNP Advanced Networking'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('');

    try {
      // Create user account
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.email + '123');
      
      // Add application to Firestore
      await addDoc(collection(db, 'applications'), {
        ...formData,
        userId: userCredential.user.uid,
        submittedAt: new Date(),
        status: 'pending'
      });

      setSubmitStatus('Application submitted successfully! Check your email for confirmation.');
      setFormData({
        firstName: '', lastName: '', email: '', phone: '', country: '', city: '',
        dateOfBirth: '', education: '', course: '', experience: '', motivation: '',
        goals: '', availability: '', computer: '', internet: ''
      });
    } catch (error: any) {
      setSubmitStatus('Error submitting application: ' + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await signInWithEmailAndPassword(auth, loginData.email, loginData.password);
      setSubmitStatus('Logged in successfully!');
      setShowLogin(false);
    } catch (error: any) {
      setSubmitStatus('Login error: ' + error.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 via-blue-700 to-red-600 text-white shadow-lg">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <div className="flex items-center space-x-4 cursor-pointer">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-xl">EAGT</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold font-pacifico">East African Girls in Tech</h1>
                  <p className="text-blue-100 text-sm">Empowering East African Girls in Technology</p>
                </div>
              </div>
            </Link>
            <button 
              onClick={() => setShowLogin(!showLogin)}
              className="bg-white text-blue-600 px-6 py-2 rounded-full font-semibold hover:bg-blue-50 transition-colors whitespace-nowrap cursor-pointer"
            >
              {showLogin ? 'Hide Login' : 'Student Login'}
            </button>
          </div>
        </div>
      </header>

      {/* Login Form */}
      {showLogin && (
        <div className="bg-white border-b border-gray-200 py-6">
          <div className="container mx-auto px-6">
            <div className="max-w-md mx-auto">
              <h3 className="text-xl font-semibold mb-4">Student Login</h3>
              <form onSubmit={handleLogin} className="space-y-4">
                <input
                  type="email"
                  placeholder="Email"
                  value={loginData.email}
                  onChange={(e) => setLoginData(prev => ({...prev, email: e.target.value}))}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
                <input
                  type="password"
                  placeholder="Password"
                  value={loginData.password}
                  onChange={(e) => setLoginData(prev => ({...prev, password: e.target.value}))}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer"
                >
                  Login
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Application Form */}
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Student Application Form</h2>
            <p className="text-xl text-gray-600">
              Join East African Girls in Tech and start your technology career journey
            </p>
          </div>

          {submitStatus && (
            <div className={`mb-6 p-4 rounded-lg ${submitStatus.includes('Error') ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
              {submitStatus}
            </div>
          )}

          <form id="student-application" onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-8">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Personal Information */}
              <div className="md:col-span-2">
                <h3 className="text-xl font-semibold text-gray-800 mb-4 border-b border-gray-200 pb-2">
                  Personal Information
                </h3>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">First Name *</label>
                <input
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Last Name *</label>
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Country *</label>
                <select
                  name="country"
                  value={formData.country}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Select Country</option>
                  {countries.map(country => (
                    <option key={country} value={country}>{country}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">City *</label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Date of Birth *</label>
                <input
                  type="date"
                  name="dateOfBirth"
                  value={formData.dateOfBirth}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Education Level *</label>
                <select
                  name="education"
                  value={formData.education}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Select Education Level</option>
                  <option value="high-school">High School</option>
                  <option value="diploma">Diploma</option>
                  <option value="bachelor">Bachelor's Degree</option>
                  <option value="master">Master's Degree</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {/* Course Selection */}
              <div className="md:col-span-2">
                <h3 className="text-xl font-semibold text-gray-800 mb-4 border-b border-gray-200 pb-2 mt-6">
                  Course Selection
                </h3>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Course *</label>
                <select
                  name="course"
                  value={formData.course}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Select Course</option>
                  {courses.map(course => (
                    <option key={course} value={course}>{course}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Availability *</label>
                <select
                  name="availability"
                  value={formData.availability}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Select Availability</option>
                  <option value="full-time">Full Time</option>
                  <option value="part-time">Part Time</option>
                  <option value="weekend">Weekends Only</option>
                  <option value="evening">Evening Classes</option>
                </select>
              </div>

              {/* Technical Requirements */}
              <div className="md:col-span-2">
                <h3 className="text-xl font-semibold text-gray-800 mb-4 border-b border-gray-200 pb-2 mt-6">
                  Technical Requirements
                </h3>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Do you have access to a computer? *</label>
                <select
                  name="computer"
                  value={formData.computer}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Select Option</option>
                  <option value="yes-own">Yes, I own one</option>
                  <option value="yes-shared">Yes, shared access</option>
                  <option value="no">No, I need assistance</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Internet Access *</label>
                <select
                  name="internet"
                  value={formData.internet}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Select Option</option>
                  <option value="reliable">Reliable daily access</option>
                  <option value="limited">Limited access</option>
                  <option value="mobile">Mobile data only</option>
                  <option value="none">No regular access</option>
                </select>
              </div>

              {/* Experience and Motivation */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Previous Tech Experience</label>
                <textarea
                  name="experience"
                  value={formData.experience}
                  onChange={handleInputChange}
                  rows={3}
                  maxLength={500}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Describe any previous experience with technology, programming, or related fields..."
                />
                <p className="text-sm text-gray-500 mt-1">{formData.experience.length}/500 characters</p>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Why do you want to join EAGT? *</label>
                <textarea
                  name="motivation"
                  value={formData.motivation}
                  onChange={handleInputChange}
                  rows={3}
                  maxLength={500}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Tell us your motivation for joining our program..."
                  required
                />
                <p className="text-sm text-gray-500 mt-1">{formData.motivation.length}/500 characters</p>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Career Goals *</label>
                <textarea
                  name="goals"
                  value={formData.goals}
                  onChange={handleInputChange}
                  rows={3}
                  maxLength={500}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="What are your career goals after completing the program?"
                  required
                />
                <p className="text-sm text-gray-500 mt-1">{formData.goals.length}/500 characters</p>
              </div>
            </div>

            <div className="mt-8">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-blue-600 to-red-600 text-white py-4 rounded-lg text-lg font-semibold hover:from-blue-700 hover:to-red-700 transition-all disabled:opacity-50 whitespace-nowrap cursor-pointer"
              >
                {isSubmitting ? 'Submitting Application...' : 'Submit Application'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}